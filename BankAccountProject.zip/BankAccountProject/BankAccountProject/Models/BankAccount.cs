﻿namespace BankAccountProject.Models
{
    public class BankAccount
    {
        public int AccountNumber { get; set; }
        public int Pin { get; set; }
    }
}
